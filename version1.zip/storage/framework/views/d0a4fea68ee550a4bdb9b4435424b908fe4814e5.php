

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>


<link href="/dist/libs/fullcalendar/core/main.min.css" rel="stylesheet"/>
<link href="/dist/libs/fullcalendar/daygrid/main.min.css" rel="stylesheet"/>
<link href="/dist/libs/fullcalendar/timegrid/main.min.css" rel="stylesheet"/>
<link href="/dist/libs/fullcalendar/list/main.min.css" rel="stylesheet"/>


    <div class="row">
        <div class="col-md-3 mb-2">
          <a href="/invoices?filter[invostatus]=1">
            <div class="card card-sm">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col-auto">
                      <span class="bg-yellow text-white avatar">                       
	                      <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 3v4a1 1 0 0 0 1 1h4" /><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" /><line x1="9" y1="7" x2="10" y2="7" /><line x1="9" y1="13" x2="15" y2="13" /><line x1="13" y1="17" x2="15" y2="17" /></svg>
                      </span>
                    </div>
                    <div class="col">
                      <div class="font-weight-medium">
                        <?php echo e(__('Unpaid_Invoices')); ?>

                      </div>
                      <div class="text-muted">
                        <?php echo e($counts['unpaid']); ?>   <?php echo e(__('Unpaid_Invoices')); ?>

                      </div>
                    </div>
                  </div>
                </div>          
              </div></a>
        </div>
        <div class="col-md-3 mb-2"> 
          <a href="/invoices?filter[invostatus]=3">
            <div class="card card-sm">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col-auto">
                      <span class="bg-lime text-white avatar">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M16.7 8a3 3 0 0 0 -2.7 -2h-4a3 3 0 0 0 0 6h4a3 3 0 0 1 0 6h-4a3 3 0 0 1 -2.7 -2"></path><path d="M12 3v3m0 12v3"></path></svg>
                      </span>
                    </div>
                    <div class="col">
                      <div class="font-weight-medium">
                        <?php echo e(__('Paid_Invoices')); ?>

                      </div>
                      <div class="text-muted">
                        <?php echo e($counts['paid']); ?>   <?php echo e(__('Paid_Invoices')); ?>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </a>
        </div>

        <div class="col-md-3 mb-2">
          <a href="/quotes">
            <div class="card card-sm">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col-auto">
                      <span class="bg-teal text-white avatar">                   
	                  <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7v-2a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v2" /><line x1="12" y1="12" x2="12" y2="12.01" /><path d="M3 13a20 20 0 0 0 18 0" /></svg>
                      </span>
                    </div>
                    <div class="col">
                      <div class="font-weight-medium">
                        <?php echo e(__('Quotes')); ?>

                      </div>
                      <div class="text-muted">
                        <?php echo e($counts['quotes']); ?>  <?php echo e(__('Quotes')); ?>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </a>
        </div>

        <div class="col-md-3 mb-2">
          <a href="/projects?filter[status]=2">
            <div class="card card-sm">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col-auto">
                      <span class="bg-blue text-white avatar">
	                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="4" width="6" height="6" rx="1" /><rect x="4" y="14" width="6" height="6" rx="1" /><rect x="14" y="14" width="6" height="6" rx="1" /><line x1="14" y1="7" x2="20" y2="7" /><line x1="17" y1="4" x2="17" y2="10" /></svg>
                      </span>
                    </div>
                    <div class="col">
                      <div class="font-weight-medium">
                        <?php echo e(__('Active_Projects')); ?>

                      </div>
                      <div class="text-muted">
                        <?php echo e($counts['prjinprogress']); ?>  <?php echo e(__('Active_Projects')); ?>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 mb-2">
            <div class="card">
                <div class="card-body">
                  <h3 class="card-title"> <?php echo e(__('Accounts_Summary')); ?></h3>
                  <div id="chart-mentions" class="chart-lg"></div>
                </div>
              </div>

        </div>
        <div class="col-md-4 mb-2">
           
                <div class="card ">
                  <div class="card-body mb-4">
                    <h3 class="card-title"> <?php echo e(__('Project_summary')); ?></h3>
                    <div id="chart-demo-pie"></div>
                  </div>
                </div>
            
        </div>
    </div>


    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">               
            <div id="calendar-main" class="card-calendar"></div>
          </div>
        </div>
      </div>

      <div class="col-lg-4">

    
          <div class="card">
            <div class="card-body">               
              <h3 class="card-title"> <?php echo e(__('Notifications')); ?></h3>
              <div class="list-group list-group-flush list-group-hoverable">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item">
                  <div class="row align-items-center">
                    <div class="col-auto"><span class="status-dot status-dot-animated <?php echo e($notif->style); ?> d-block"></span></div>
                    <div class="col text-truncate">
                      <a href="<?php echo e($notif->link); ?>" class="text-body d-block">From <?php echo e($notif->added->name); ?> <?php echo e($notif->created_at->diffForHumans()); ?></a>
                      <div class="d-block text-muted text-truncate mt-n1">
                       <?php echo e($notif->message); ?>

                      </div>
                    </div>
                    <div class="col-auto">
                      <a href="/notification/update/<?php echo e($notif->id); ?>" class="list-group-item-actions">
                     
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-checkbox" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                          <polyline points="9 11 12 14 20 6"></polyline>
                          <path d="M20 12v6a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h9"></path>
                       </svg>
                      </a>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
          </div>
    

        <div class="card mt-3">
          <div class="card-body">               
            <h3 class="card-title"> <?php echo e(__('My_Tasks')); ?></h3>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <div class="col-12 mb-3">
            <div class="card card-sm">
              <div class="ribbon ribbon-top ribbon-bookmark <?php echo e($task->type); ?>">
                <?php if($task->status==1): ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-loader" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                  <line x1="12" y1="6" x2="12" y2="3"></line>
                  <line x1="16.25" y1="7.75" x2="18.4" y2="5.6"></line>
                  <line x1="18" y1="12" x2="21" y2="12"></line>
                  <line x1="16.25" y1="16.25" x2="18.4" y2="18.4"></line>
                  <line x1="12" y1="18" x2="12" y2="21"></line>
                  <line x1="7.75" y1="16.25" x2="5.6" y2="18.4"></line>
                  <line x1="6" y1="12" x2="3" y2="12"></line>
                  <line x1="7.75" y1="7.75" x2="5.6" y2="5.6"></line>
               </svg>
                <?php else: ?> 
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-checks" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                  <path d="M7 12l5 5l10 -10"></path>
                  <path d="M2 12l5 5m5 -5l5 -5"></path>
               </svg>
                <?php endif; ?>
              </div>
              <div class="card-body">
                <?php if($task->status==1): ?><a href="/mytasks/view/<?php echo e($task->id); ?>"> <h3 class="card-title">Project Name - Case ID #<?php echo e($task->id); ?></h3></a> <?php else: ?>
                <a href="/mytasks/view/<?php echo e($task->id); ?>">  <s> <h3 class="card-title">Project Name - Case ID #<?php echo e($task->id); ?></h3></a> </s> <?php endif; ?>

             
                <div class="text-muted"><?php echo e($task->task); ?></div>
                <div class="mt-4">
                  <div class="row">
                    <div class="col">
                      <div class="avatar-list avatar-list-stacked">
                        <?php if($task->assignedto): ?>                          
                       <span class="avatar  rounded-circle" data-toggle="tooltip" data-placement="bottom" style="background-image: url(<?php echo e($task->assigned->profile_photo_url); ?>)" title="Assigned to : <?php echo e($task->assigned->name); ?> "></span>                      
                         <?php endif; ?>
                   
                       
                      </div>
                    </div>
                    <div class="col-auto text-muted">
                        <div class="spinner-grow <?php echo e($task->type); ?>" style="height: 12px; width:12px; padding-top: -15px" role="status"></div>
                 
                    </div>
                    <div class="col-auto">
                      <a href="#" class="link-muted"><!-- Download SVG icon from http://tabler-icons.io/i/message -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                       <?php echo e($task->comments->count()); ?></a>
                    </div>
                    <div class="col-auto">
                        <a href="/project/tasks/delete/<?php echo e($task->id); ?>" onclick="return confirm('Are you sure?')" class="text-muted">
                         <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg>
                        </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
      

    </div>  
  
        
<div class="card mt-3">
    <div class="card-header">
      <h3 class="card-title"><?php echo e(__('Unpaid_Invoices')); ?></h3>
      <button type="button" data-toggle="modal" data-target="#modal-simple"
      style="float: right; right:0; margin-right:10px; position: absolute;"
      class="btn btn-warning btn-sm"><?php echo e(__('Create_new_invoice')); ?></button>
    </div>

    <div class="table-responsive">
      <table class="table card-table table-vcenter text-nowrap datatable">
        <thead>
            <tr>
                <th><?php echo e(__('INVO_ID')); ?> </th>
                <th><?php echo e(__('TITLE')); ?> </th>
                <th><?php echo e(__('CLIENT')); ?> </th>
                <th><?php echo e(__('DATE')); ?> </th>
                <th><?php echo e(__('DUE_DATE')); ?>  </th>
                <th><?php echo e(__('AMOUNT')); ?></th>
                <th><?php echo e(__('PAID')); ?></th>
                <th><?php echo e(__('STATUS')); ?></th>
                
                <th></th>
            </tr>
        </thead>
        <tbody>
          
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               
                <td>
                    
                   # <?php echo e($invoice->invoid); ?>

                </td>
                <td><a href="<?php echo e(route('editinvoice', ['id' => $invoice->id])); ?>"> <?php echo e($invoice->title); ?></a></td>
                <td>
                  <a href="/client/ <?php echo e(!empty($invoice->clientdata) ? $invoice->clientdata->id:''); ?>">   <?php echo e(!empty($invoice->clientdata) ? $invoice->clientdata->name:'Removed'); ?> </a>
                </td>
                <td>
                    <?php echo e($invoice->invodate); ?>

                </td>
                <td> <?php echo e($invoice->duedate); ?>

                </td>
                <td> <?php echo e($invoice->totalamount); ?>

                </td>
                <td> <?php echo e($invoice->paidamount); ?>

                </td>
                <td><?php $todaydate = date('Y-m-d');  ?>
                            <?php if($invoice->invostatus ==1): ?><?php if($invoice->duedate < $todaydate): ?><span class="badge bg-red">Overdue</span> <?php else: ?> <span class="badge bg-yellow">Unpaid</span>   <?php endif; ?> <?php endif; ?>
                            <?php if($invoice->invostatus ==2): ?><?php if($invoice->duedate < $todaydate): ?><span class="badge bg-red">Overdue</span> <?php else: ?> <span class="badge bg-indigo">Part Paid</span>  <?php endif; ?> <?php endif; ?>
                            <?php if($invoice->invostatus ==3): ?><span class="badge bg-green">Paid</span><?php endif; ?>
                            <?php if($invoice->invostatus ==4): ?><span class="badge bg-purple">Refuned</span><?php endif; ?>
                            <?php if($invoice->invostatus ==5): ?><span class="badge bg-dark">Cancelled</span><?php endif; ?>    
                </td>
               
                <td class="text-right">
                    <span class="dropdown ml-1">
                        <button class="btn  btn-sm dropdown-toggle align-text-top"
                            data-boundary="viewport" data-toggle="dropdown">Actions</button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="/invoice/edit/<?php echo e($invoice->id); ?>">
                              <?php echo e(__('Edit_Invoice')); ?>

                            </a>
                            <a class="dropdown-item" onclick="return confirm('Are you sure?')"
                                href="/invoice/delete/<?php echo e($invoice->id); ?>">
                                <?php echo e(__('Delete_Invoice')); ?>

                            </a>
                        </div>
                    </span>
                </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="card-footer d-flex align-items-center">
      <p class="m-0 text-muted"><?php echo e(__('Showing')); ?>  <?php echo e($invoices->count()); ?> <?php echo e(__('entries')); ?></p>
      <ul class="pagination m-0 ms-auto">
        <?php echo e($invoices->links()); ?>

      </ul>
    </div>
  </div>


  
  <div class="modal modal-blur fade" id="modal-simple" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Create New Invoice</h5>
          <b type="button" class="close" data-dismiss="modal" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-x" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
           </svg>
          </b>
        </div>
    <form action="<?php echo e(route('createnewinvoice')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="mb-2">
                <label class="form-label">Invoice Title</label>
                <input type="text" class="form-control" name="title" placeholder="Invoice Title Here">
            </div>
            <div class="mb-2">
                <label class="form-label">Select Client <a href="<?php echo e(route('addclient')); ?>" style="float:right;"> Add New Client </a></label>
                <select name="userid" id="select-users" class="form-select">
                   <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
            
           
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-white mr-auto" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success" >Create Invoice</button>
        </div>
        </form>
      </div>
    </div>
  </div>
    


  <script src="/dist/libs/fullcalendar/core/main.min.js"></script>
  <script src="/dist/libs/fullcalendar/daygrid/main.min.js"></script>
  <script src="/dist/libs/fullcalendar/interaction/main.min.js"></script>
  <script src="/dist/libs/fullcalendar/timegrid/main.min.js"></script>
  <script src="/dist/libs/fullcalendar/list/main.min.js"></script>



    <script src="/dist/libs/apexcharts/dist/apexcharts.min.js"></script>

<script>
        // @formatter:off
        document.addEventListener("DOMContentLoaded", function () {
            window.ApexCharts && (new ApexCharts(document.getElementById('chart-mentions'), {
                chart: {
                    type: "bar",
                    fontFamily: 'inherit',
                    height: 240,
                    parentHeightOffset: 0,
                    toolbar: {
                        show: false,
                    },
                    animations: {
                        enabled: true
                    },
                    stacked: false,
                },
                plotOptions: {
                    bar: {
                        columnWidth: '40%',
                    }
                },
                dataLabels: {
                    enabled: false,
                },
                fill: {
                    opacity: 1,
                },
                series: [{
                    name: "Income",
                    data: [ <?php for($i=0; $i<40; $i++): ?> '<?php echo e($datas[$i]['count']); ?>' , <?php endfor; ?> ]
                },
                {
                    name: "Expense",
                    data: [ <?php for($i=0; $i<40; $i++): ?> '<?php echo e($quotedata[$i]['count']); ?>' , <?php endfor; ?> ]
                }],
                grid: {
                    padding: {
                        top: -20,
                        right: 0,
                        left: -4,
                        bottom: -4
                    },
                    strokeDashArray: 4,
                    xaxis: {
                        lines: {
                            show: false
                        }
                    },
                },
                xaxis: {
                    labels: {
                        padding: 0
                    },
                    tooltip: {
                        enabled: false
                    },
                    axisBorder: {
                        show: false,
                    },
                    type: 'datetime',
                },
                yaxis: {
                    labels: {
                        padding: 4
                    },
                },
                labels: [ <?php for($i=0; $i<40; $i++): ?> ' <?php echo e($datas[$i]['date']); ?> ' , <?php endfor; ?>
                    ],
                colors: ["#74B816", "#F59F00", "#bfe399"],
                legend: {
                    show: true,
                    position: 'bottom',
                    height: 32,
                    offsetY: 8,
                    markers: {
                        width: 8,
                        height: 8,
                        radius: 100,
                    },
                    itemMargin: {
                        horizontal: 8,
                    },
                },
            })).render();
        });
        // @formatter:on
      </script>

<script>
    // @formatter:off
    document.addEventListener("DOMContentLoaded", function () {
        window.ApexCharts && (new ApexCharts(document.getElementById('chart-demo-pie'), {
            chart: {
                type: "donut",
                fontFamily: 'inherit',
                height: 240,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            fill: {
                opacity: 1,
            },
            series: [<?php echo e($counts['prjnotstart']); ?>, <?php echo e($counts['prjinprogress']); ?>, <?php echo e($counts['prjinreview']); ?>, <?php echo e($counts['prjincompleted']); ?>],
            labels: ["Not Started", "In Progress", "In Review", "Completed"],
            grid: {
                strokeDashArray: 4,
            },
            colors: ["#C6CAD0", "#4299E1", "#F59F00", "#2FB344"],
            legend: {
                show: true,
                position: 'bottom',
                offsetY: 12,
                markers: {
                    width: 10,
                    height: 10,
                    radius: 100,
                },
                itemMargin: {
                    horizontal: 8,
                    vertical: 8
                },
            },
            tooltip: {
                fillSeriesColor: false
            },
        })).render();
    });
    // @formatter:on
  </script>


  
  <script>
      document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar-main'),
               today = new Date(),
               y = today.getFullYear(),
               m = today.getMonth(),
               d = today.getDate();
            window.FullCalendar && (new FullCalendar.Calendar(calendarEl, {
      	   plugins: [ 'interaction', 'dayGrid','dayGridWeek' ],
               themeSystem: 'standard',
      	   header: {
      		   left: 'dayGrid,dayGridWeek,dayGridMonth',
      		   center: '',
      		   right: 'prev,next,'
      	   },
      	   selectable: true,
      	   selectHelper: true,
      	   nowIndicator: true,
      	   views: {
      		   dayGridMonth: { buttonText: ' Month' },
      		   dayGridWeek: { buttonText: ' Week' },
                 dayGrid: { buttonText: 'Today' }
      		  
      	   },
      	   defaultView: 'dayGridMonth',
      	   timeFormat: 'H(:mm)',
      	   events: [
       
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                 {
                     title: '<?php echo e($task->task); ?>',
                     start: '<?php echo e($task->created_at); ?>',
                     className: '<?php echo e($task->type); ?>',
                     url: '/mytasks/view/<?php echo e($task->id); ?>'
                  },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
               ]
         })).render();
      });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/dashboard.blade.php ENDPATH**/ ?>