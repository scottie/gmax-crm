<button  <?php echo e($attributes->merge(['type' => 'button',  'class' => 'btn btn-danger'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\gmax\livetest\vendor\laravel\jetstream\src/../resources/views/components/danger-button.blade.php ENDPATH**/ ?>