

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-3">
        <?php echo $__env->make('app.projectnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     
        <style>
            .ck-editor__editable_inline {
            color:rgb(14, 17, 14);
           
            }
    </style>

    </div>
    <div class="col-md-9">      
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Project Note</h3>
                      </div>
                    <div class="card-body p-2">
                    <form action="<?php echo e(route('updatenoteprjct')); ?>" method="post" enctype="multipart/form">
                        <?php echo csrf_field(); ?> 
                        <input type="hidden" name="id" value="<?php echo e($note->id); ?>">
                        <textarea id="editor" class="form-control" style="width: 100%;  background-color: #ffffff0a;
                        " id="editor" name="note" rows="6">
                            <?php echo $note->note; ?>

                        </textarea>
                       
                  
                    </div>
                    <div class="card-footer">
                        <div class="d-flex">
                            <a href="#" class="btn btn-link">Last updated by <?php echo e($note->admindata->name); ?> </a>
                          <button type="submit"  class="btn btn-primary ms-auto">Save</a>
                        </div>
                      </div>
                    </form>
                </div>
             </div>      
             


        </div>
        
    </div>
    
</div> 



<script src="https://cdn.ckeditor.com/ckeditor5/11.0.1/classic/ckeditor.js"></script>

<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )     
        .catch( error => {
            console.error( error );
            
        } );


</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/app/projectviewnote.blade.php ENDPATH**/ ?>