

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>


<div class="card">
    <div class="card-header">
      <h3 class="card-title">Client Manager</h3>
    </div>

    <div class="table-responsive">
      <table class="table card-table table-vcenter text-nowrap datatable">
        <thead>
            <tr>
                <th>Name </th>
                <th>Business </th>
                <th>Email </th>
                <th>Phone </th>
                <th>Type </th>
                <th>Status </th>
                <th>Added</th>                
                <th></th>
            </tr>
        </thead>
        <tbody>
          
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="/client/<?php echo e($client->id); ?>" class="text-reset" tabindex="-1"> <?php echo e($client->name); ?></a></td>
                <td>
                    
                    <?php echo e($client->business); ?>

                </td>
                <td>
                    <?php echo e($client->email); ?>

                </td>
                <td> <?php echo e($client->phone); ?>

                </td>
                <td> <?php echo e($client->phone); ?>

                </td>
                <td>
                    <span class="badge bg-cyan">New</span> </td>
                <td><?php echo e($client->created_at->diffForHumans()); ?></td>
                
                <td class="text-right">
                    <span class="dropdown ml-1">
                        <button class="btn  btn-sm dropdown-toggle align-text-top"
                            data-boundary="viewport" data-toggle="dropdown">Actions</button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="/client/edit/<?php echo e($client->id); ?>">
                                Edit Client
                            </a>
                            <a class="dropdown-item" onclick="return confirm('Warning: All Projects and Invoices will deleted with client. Are you sure?')"
                                href="/client/delete/<?php echo e($client->id); ?>">
                                Delete Client
                            </a>
                        </div>
                    </span>
                </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="card-footer d-flex align-items-center">
      <p class="m-0 text-muted">Showing  <?php echo e($clients->count()); ?> entries</p>
      <ul class="pagination m-0 ms-auto">
        <?php echo e($clients->links()); ?>

      </ul>
    </div>
  </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/app/listofclients.blade.php ENDPATH**/ ?>