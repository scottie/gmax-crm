
<?php $__env->startSection('content'); ?>


<script src="/js/jspdf.debug.js"></script>
<script src="/js/html2canvas.min.js"></script>
<script src="/js/html2pdf.min.js"></script>

  <?php
  if($business->logo){ 
  $image = public_path('storage/uploads/').$business->logo;
$type = pathinfo($image, PATHINFO_EXTENSION);
$data = file_get_contents($image);
$dataUri = 'data:image/' . $type . ';base64,' . base64_encode($data);
  }
if($business->headerimage){
$headerimage = public_path('storage/uploads/').$business->headerimage;
$headerimagetype = pathinfo($headerimage, PATHINFO_EXTENSION);
$headerimagedata = file_get_contents($headerimage);
$headerimagedataUri = 'data:image/' . $headerimagetype . ';base64,' . base64_encode($headerimagedata);
}
if($business->footerimage){
$footerimage = public_path('storage/uploads/').$business->footerimage;
$footerimagetype = pathinfo($footerimage, PATHINFO_EXTENSION);
$footerimagedata = file_get_contents($footerimage);
$footerimagedataUri = 'data:image/' . $footerimagetype . ';base64,' . base64_encode($footerimagedata);
}
  ?>
    <div class="row">
       
        <div class="col-md-9">
            <div class="card card-lg">
                <div class="card-body"  id="invoice">
                  <div class="row">
                    <div class="col-md-12">
                      <?php if($business->headerimage!=NULL): ?>
                      <img src="<?php echo e($headerimagedataUri); ?>" width="100%">
                      <?php endif; ?>
                    </div>
                    <div class="col-6">
                      <?php if($business->enablelogo!=1): ?>
                        <img src="<?php echo e($dataUri); ?>" width="200">
                      <?php endif; ?>
                      <address class="mt-2">
                        <strong><?php echo e($business->businessname); ?></strong> <br>
                        <?php if($business->address!=NULL): ?>  <?php echo e($business->address); ?><br><?php endif; ?>
                        <?php if($business->address2!=NULL): ?> <?php echo e($business->address2); ?><br> <?php endif; ?>
                        <?php if($business->city!=NULL): ?>   <?php echo e($business->city); ?>, <?php endif; ?>  <?php if($business->state!=NULL): ?>  <?php echo e($business->state); ?><br> <?php endif; ?>
                        <?php if($business->email!=NULL): ?>    <?php echo e($business->email); ?>, <?php endif; ?>  <?php if($business->contactnum!=NULL): ?>  <?php echo e($business->contactnum); ?><br> <?php endif; ?>
                        <?php if($business->taxid!=NULL): ?>   <?php echo e($settings->taxname); ?> : <?php echo e($business->taxid); ?><br> <?php endif; ?>
          
                      </address>
                    </div>
                    <div class="col-6 text-end mr-1" >                       
                     
                                                    
                      <address class="mt-4" style="margin-right: 5px;">             
                        <strong><?php echo e($invoice->clientdata->name); ?></strong> <br>
                        <?php echo e($invoice->clientdata->business); ?><br>
                        <?php echo e($invoice->clientdata->address); ?><br>
                        <?php echo e($invoice->clientdata->state); ?>, <?php echo e($invoice->clientdata->city); ?><br>
                        <?php echo e($invoice->clientdata->country); ?>, <?php echo e($invoice->clientdata->zip); ?><br>
                        <?php echo e($invoice->clientdata->email); ?>

                      </address>
                    </div>
                    <div class="col-12 my-3">
                      <h3>Title: <?php echo e($invoice->title); ?></h3>
                  
                        <address>
                          <strong> Invoice : #<?php echo e($invoice->invoid); ?> </strong>  <br>
                            <strong>  Invoice Date:</strong>  <?php echo e($invoice->invodate); ?><br>
                              <strong>  Due Date :</strong> <?php echo e($invoice->duedate); ?><br>
                                <strong >  Status :</strong>  <?php if($invoice->invostatus ==1): ?><span class="badge bg-yellow text-uppercase">Unpaid</span><?php endif; ?>
                                      <?php if($invoice->invostatus ==2): ?><span class="badge bg-indigo text-uppercase">partly paid</span><?php endif; ?>
                                      <?php if($invoice->invostatus ==3): ?><span class="badge bg-green text-uppercase">Paid</span><?php endif; ?>
                                      <?php if($invoice->invostatus ==4): ?><span class="badge bg-purple text-uppercase">Refuned</span><?php endif; ?>
                                      <?php if($invoice->invostatus ==5): ?><span class="badge bg-dark text-uppercase">Cancelled</span><?php endif; ?>    
                          </address>
                    </div>
                  </div>
                  <table class="table table-transparent table-responsive">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 1%">#</th>
                        <th>Item</th>
                        <th class="text-center" style="width: 10%">Qnt</th>
                        <th class="text-end" style="width: 1%">Amount</th>
                        <?php if($invoice->taxable==1): ?>
                        <th class="text-end" style="width: 1%">Tax</th>
                        <?php endif; ?>
                        <th class="text-end" style="width: 1%">Total</th>
                      </tr>
                    </thead>
                    <?php $totalamt =0;  $invokey =1; $tottax =0; ?>
                    <?php $__currentLoopData = $invometas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invometa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="text-center"><?php echo $invokey; $invokey ++; ?> </td>
                      <td>
                      
                        <div class=""><?php echo e($invometa->meta); ?></div>
                      </td>
                      <td class="text-center">
                        <?php echo e($invometa->qty); ?><small><?php echo e($invometa->qtykey); ?></small>
                      </td>
                      <?php if($invoice->taxable==1): ?>
                      <td class="text-end"><?php echo e($settings->prefix); ?><?php echo e($invometa->amount); ?></td>
                      <?php endif; ?>
                      <td class="text-end"><?php echo e($settings->prefix); ?><?php echo $invometa->tax; $tottax +=$invometa->tax;  ?> </td>
                      <td class="text-end"><?php echo e($settings->prefix); ?><?php echo e($invometa->total); ?> <?php $totalamt +=$invometa->amount*$invometa->qty; ?></td>
                    </tr>
              
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td colspan="<?php if($invoice->taxable==1): ?> 5 <?php else: ?> 4 <?php endif; ?>" class="strong text-end"> <?php if($invoice->taxable==1): ?>Total Before Tax <?php else: ?> Sub Total <?php endif; ?></td>
                      <td class="text-end"><?php echo e($settings->prefix); ?><?php echo e($totalamt); ?></td>
                    </tr>
                    <?php if($invoice->taxable==1): ?>
                    <tr>
                      <td colspan="5" class="strong text-end"><?php echo e($settings->taxname); ?></td>
                      <td class="text-end"><?php echo e($settings->taxpercent); ?>%</td>
                    </tr>
                    <tr>
                      <td colspan="5" class="strong text-end"><?php echo e($settings->taxname); ?> Due</td>
                      <td class="text-end"><?php echo e($settings->prefix); ?><?php echo e($tottax); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                      <td colspan="<?php if($invoice->taxable==1): ?> 5 <?php else: ?> 4 <?php endif; ?>" class="font-weight-bold text-uppercase text-end">Total Due</td>
                      <td class="font-weight-bold text-end"><?php echo e($settings->prefix); ?><?php echo e($invoice->totalamount); ?></td>
                    </tr>
                  </table>
                  <?php if($payments->count()>0): ?>
                  <h3 class="mt-4">Transactions </h3>
                  <table class="table table-transparent table-responsive">
                    <thead>
                      <tr>                        
                        <th>Transaction Date</th>
                        <th class="text-center">Gateway</th>
                        <th class="text-end">Transaction ID</th>
                        <th class="text-end" >Amount</th>
                      </tr>
                    </thead>
                    <?php $totalpaid = 0; ?>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="text-left"><?php echo e($payment->date); ?></td>
                      <td>
                      
                        <div class=""><?php echo e($payment->method); ?></div>
                      </td>
                      <td class="text-center">
                        <?php echo e($payment->transation); ?>  
                      </td>
                      
                      <td class="text-end"> <?php echo e($settings->prefix); ?><?php echo e($payment->amount); ?>

                        <?php $totalpaid += $payment->amount; ?></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    <tr>
                      <td colspan="3" class=" font-weight-bold text-end">Total Paid</td>
                      <td class=" text-end"><?php echo e($settings->prefix); ?><?php echo e($totalpaid); ?></td>
                    </tr>
                    <tr>
                        <td colspan="3" class="font-weight-bold text-uppercase text-end">Balance Due</td>
                        <td class="font-weight-bold text-end"><?php echo e($settings->prefix); ?><?php echo $invoice->totalamount - $invoice->paidamount  ?></td>
                      </tr>
                  </table>
                  <?php endif; ?>
                  <p class="text-muted text-center mt-5"><?php echo e($settings->invoicenote); ?></p>

                  <div class="col-md-12">
                    <?php if($business->footerimage!=NULL): ?>
                    <img src="<?php echo e($footerimagedataUri); ?>" width="100%">
                    <?php endif; ?>
                  </div>

                </div>
              </div>
            </div>

            <div class="col-md-3">
                <div class="dropdown-menu dropdown-menu-demo">
                    <span class="dropdown-header">Menu</span>
                    <a class="dropdown-item " href="/invoice/edit/<?php echo e($invoice->id); ?>">                  
                   
                	<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24"   style="margin-right: 10px;" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 7h-3a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-3" /><path d="M9 15h3l8.5 -8.5a1.5 1.5 0 0 0 -3 -3l-8.5 8.5v3" /><line x1="16" y1="5" x2="19" y2="8" /></svg>
                         Edit Invoice
                    </a>
                    <a class="dropdown-item btn-download"  href="javascript:void(0)" >            
                    <svg xmlns="http://www.w3.org/2000/svg"  style="margin-right: 10px;" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" /><polyline points="7 11 12 16 17 11" /><line x1="12" y1="4" x2="12" y2="16" /></svg>
                            Download PDF
                    </a>
                    <a class="dropdown-item " data-toggle="modal" data-target="#paymentlink">          
                   
	                <svg xmlns="http://www.w3.org/2000/svg"  style="margin-right: 10px;" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M11 7h-5a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-5" /><line x1="10" y1="14" x2="20" y2="4" /><polyline points="15 4 20 4 20 9" /></svg>
                            Payment Link
                    </a>
                    <a class="dropdown-item " href="/invoice/email/<?php echo e($invoice->id); ?>" onclick="return confirm('Are you sure?')"  >            
                       
	                <svg xmlns="http://www.w3.org/2000/svg"  style="margin-right: 10px;" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="12" r="4" /><path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" /></svg>
                                Send Email
                    </a>
                    <a class="dropdown-item " href="#"  onclick="printDiv('invoice')">            
                            
                	<svg xmlns="http://www.w3.org/2000/svg"  style="margin-right: 10px;" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M17 17h2a2 2 0 0 0 2 -2v-4a2 2 0 0 0 -2 -2h-14a2 2 0 0 0 -2 2v4a2 2 0 0 0 2 2h2" /><path d="M17 9v-4a2 2 0 0 0 -2 -2h-6a2 2 0 0 0 -2 2v4" /><rect x="7" y="13" width="10" height="8" rx="2" /></svg>
                               Print Invoice
                    </a>    
                   
                 
                </div>
            </div>

        </div>
    </div>

        <!---- get payment link --->


        <div class="modal modal-blur fade" id="paymentlink" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Get Payment Link</h5>
                <b type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-x" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                 </svg>
                </b>
              </div>
          
              <div class="modal-body">
                  
                  <div class="mb-2">
                      <label class="form-label">Payment Link</label>
                      <input type="text" class="form-control" placeholder="Payment link" value="<?php echo URL::to('/');?>/invoice/pay/<?php echo e($invoice->id); ?>">
                  </div>
                  
              </div>
              <div class="modal-footer">
              
              
              </div>
              </form>
            </div>
          </div>
        </div>


          

      
<script>

    const options = {
      margin: 0.5,
      filename: 'invoice<?php echo e($invoice->invoid); ?>.pdf',
      image: { 
        type: 'jpeg', 
        quality: 100
      },
      html2canvas: { 
        scale: 4 
      },
      jsPDF: { 
        unit: 'in', 
        format: 'letter', 
        orientation: 'portrait' 
      }
    }
    
    $('.btn-download').click(function(e){
      e.preventDefault();
      const element = document.getElementById('invoice');
      html2pdf().from(element).set(options).save();
     
    });


    function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/app/viewinvoice.blade.php ENDPATH**/ ?>