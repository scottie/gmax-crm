 <?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

       

    <link href="/dist/css/tabler.min.css" rel="stylesheet"/>
    <link href="/dist/css/demo.min.css" rel="stylesheet"/>
    <body class="antialiased border-top-wide border-primary d-flex flex-column">
        <div class="page page-center">
          <div class="container-tight " style="margin-top:65px;">
            <div class="text-center mb-4">
              <a href="."><img src="/storage/uploads/<?php echo e($settings->logo); ?>" height="36" alt=""></a>
            </div>
            <div class="card">
              <div class="card-body py-4">
                <h2 class="card-title text-center mb-4"><?php echo e(__('Login_to_your_account')); ?></h2>
                
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <?php if(session('status')): ?>
    <div class="alert alert-info" role="alert">
        <h4 class="alert-title">Notification</h4>
        <div class="text-muted"> <?php echo e(session('status')); ?>.</div>
    </div>
    <?php endif; ?>
               
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label class="form-label"><?php echo e(__('Email_address')); ?></label>
                   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'email','class' => 'block mt-1 w-full','type' => 'email','placeholder' => ''.e(__('Email_address')).'','name' => 'email','value' => old('email'),'required' => true,'autofocus' => true]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'email','class' => 'block mt-1 w-full','type' => 'email','placeholder' => ''.e(__('Email_address')).'','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'required' => true,'autofocus' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="mb-2">
                  <label class="form-label">
                    <?php echo e(__('Password')); ?>

                    <span class="form-label-description">
                      <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('I_forgot_password')); ?></a>
                    </span>
                  </label>
                  <div class="input-group input-group-flat">
                    
                    <input type="password" class="form-control"  placeholder="<?php echo e(__('Password')); ?>"  name="password"  required autocomplete="current-password">
                    <span class="input-group-text">
                      
                    </span>
                  </div>
                </div>
                <div class="mb-2">
                  <label class="form-check">                   
                    <input id="remember_me" type="checkbox" class="form-check-input" name="remember">
                    <span class="form-check-label"><?php echo e(__('Remember_me_on_this_device')); ?></span>
                  </label>
                </div>
                <div class="form-footer">
                  <button type="submit" class="btn btn-primary w-100"><?php echo e(__('Sign_In')); ?></button>
                </div>
              </div>
             
           
            </form>
           
          </div>
          </div>
        </div>
    
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/auth/login.blade.php ENDPATH**/ ?>