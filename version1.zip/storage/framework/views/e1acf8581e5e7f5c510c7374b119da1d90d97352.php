

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-xl">
    <div class="row">
        <div class="col-lg-4">
          <?php echo $__env->make('settings.settingsmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Software Settings</div>
                    <div class="mb-2">
                       Configure Your Business name and logo etc
                    </div>
                   
                    <form action="<?php echo e(route('updatesettingssave')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Your Business Name</label>
                            <input type="text" class="form-control" name="businessname" value="<?php echo e($settings->companyname); ?>">
                        </div>
                       
                       
                        <div class="mb-3">
                            <label class="form-label">Logo (.png)</label>
                            <input type="file" class="form-control" name="logo">
                        </div>

               



                        <button type="submit" style="float: right" class="btn btn-success">
                            Update Software
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/settings/settings.blade.php ENDPATH**/ ?>