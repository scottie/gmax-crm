

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-xl">
    <div class="row">
        <div class="col-lg-4">
          <?php echo $__env->make('settings.settingsmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                
                   
                    <form action="<?php echo e(route('businesssettingsave')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                                                           
                        <div class="card-title">Business Settings</div>
                        <div class="mb-2">
                           Update Your Business informations it will visible in your invoices and quotes
                         </div>
                        <div class="row">
                           
                            <div class="col-md-12">
                                <div class="mb-2">
                                    <label class="form-label">Business Name</label>
                                    <input type="text" class="form-control" name="businessname" value="<?php echo e($business->businessname); ?>" placeholder="Business Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Email</label>
                                    <input type="text" class="form-control" name="email" value="<?php echo e($business->email); ?>" placeholder="Email">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Phone</label>
                                    <input type="text" class="form-control" name="contactnum" value="<?php echo e($business->contactnum); ?>" placeholder="Phone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Tax Info</label>
                                    <input type="text" class="form-control" name="taxid" value="<?php echo e($business->taxid); ?>" placeholder="Tax Info">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Logo</label>
                                    <input type="file" class="form-control" name="logo" value="<?php echo e($business->logo); ?>" placeholder="Logo">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="" style="margin-top:30px;">
                                  
                                   <img src="/storage/uploads/<?php echo e($business->logo); ?>" height="30">
                                </div>
                            </div>
                        
                        </div>

                           <hr style="margin-top: 25px; margin-bottom: 25px;">

                     
                        <div class="row">
                           
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Address</label>
                                    <input type="text" class="form-control" name="address" value="<?php echo e($business->address); ?>" placeholder="Address">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Address Line 2</label>
                                    <input type="text" class="form-control" name="address2" value="<?php echo e($business->address2); ?>" placeholder="Address Line 2">
                                </div>
                            </div>

                            
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">City</label>
                                    <input type="text" class="form-control" name="city" value="<?php echo e($business->city); ?>" placeholder="City">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">State</label>
                                    <input type="text" class="form-control" name="state" value="<?php echo e($business->state); ?>" placeholder="State">
                                </div>
                            </div>
                          

                            
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Country</label>
                                    <input type="text" class="form-control" name="country" value="<?php echo e($business->country); ?>" placeholder="Country">
                                </div>
                            </div>
                           
                          
                          
                           </div>

                         

                        <button type="submit" style="float: right; margin-top: 15px;" class="btn btn-success">
                            Update Business Info
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/settings/business.blade.php ENDPATH**/ ?>