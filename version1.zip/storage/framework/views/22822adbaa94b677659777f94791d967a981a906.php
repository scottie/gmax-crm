

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-xl">
    <div class="row">
        <div class="col-lg-4">
          <?php echo $__env->make('settings.settingsmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                
                   
                    <form action="<?php echo e(route('invoicesettingssave')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                                                           
                        <div class="card-title">Customize Invoice</div>
                        <div class="mb-2">
                           Add/Change Invoice Header and Footer Images. 
                         </div>
                        <div class="row">
                           
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Invoice Header</label>
                                    <input type="file" class="form-control" name="headerimage" value="<?php echo e($business->headerimage); ?>" placeholder="Logo">
                                </div>
                                <img src="/storage/uploads/<?php echo e($business->headerimage); ?>">
                                <br>
                                <div class="mt-4" >
                                    <label class="form-label">Hide Basic Logo?</label>
                                    <label class="form-check">                                      
                                        <input class="form-check-input" name="enablelogo" value="1" type="checkbox" <?php if($business->enablelogo==1): ?> checked <?php endif; ?>>
                                        <span class="form-check-label">Check this if you have a logo image on Header Image File</span>
                                      </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label class="form-label">Invoice Footer</label>
                                    <input type="file" class="form-control" name="footerimage" value="<?php echo e($business->footerimage); ?>" placeholder="Logo">
                                </div>
                                <img src="/storage/uploads/<?php echo e($business->footerimage); ?>">
                            </div>
                           </div>

                         

                        <button type="submit" style="float: right; margin-top: 15px;" class="btn btn-success">
                            Update Invoice
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/settings/invoicesettings.blade.php ENDPATH**/ ?>