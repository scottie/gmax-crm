<button <?php echo e($attributes->merge(['type' => 'submit', 'style' => 'float:right; margin-top:10px;', 'class' => 'btn btn-success '])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\gmax\livetest\vendor\laravel\jetstream\src/../resources/views/components/button.blade.php ENDPATH**/ ?>