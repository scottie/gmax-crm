

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<style>
    body
    {
        font-size: 14px;
    }
    </style>


<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="/vendor/file-manager/css/file-manager.css">

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?php echo e(__('File_Manager')); ?></h3> 
      </div>
    <div class="card-body">
        <div id="fm" style="height: 800px; float:left;">

        </div>
    </div>
</div>
<script src="/vendor/file-manager/js/file-manager.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmax\livetest\resources\views/app/filemanager.blade.php ENDPATH**/ ?>