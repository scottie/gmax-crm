<div class="" <?php echo e($attributes); ?>>

  

   
            <?php echo e($content); ?>

      
</div>
<?php /**PATH C:\xampp\htdocs\gmax\livetest\vendor\laravel\jetstream\src/../resources/views/components/action-section.blade.php ENDPATH**/ ?>