<?php $attributes = $attributes->exceptProps(['submit']); ?>
<?php foreach (array_filter((['submit']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => ''])); ?>>

         <?php $__env->slot('title'); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
         <?php $__env->slot('description'); ?> <?php echo e($description); ?> <?php $__env->endSlot(); ?>


    <div class="">
        <form wire:submit.prevent="<?php echo e($submit); ?>">
            <div class="">
                <div class="">
                    <div class="">
                        <?php echo e($form); ?>

                    </div>
                </div>

                <?php if(isset($actions)): ?>
                    <div class="">
                        <?php echo e($actions); ?>

                    </div>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\gmax\livetest\vendor\laravel\jetstream\src/../resources/views/components/form-section.blade.php ENDPATH**/ ?>